package 상속응용;

import javax.swing.JFrame;

public class 내창 extends JFrame{
	String title;
	
	public 내창(String title) {
		this.title = title;
	}
}
