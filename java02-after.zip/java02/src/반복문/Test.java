package �ݺ���;

import javax.swing.JOptionPane;

public class Test {

	public static void main(String[] args) {
		String name = JOptionPane.showInputDialog("�̸� �Է�");
	}

}
