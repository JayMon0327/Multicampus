package �ݺ���;

public class For������2 {

	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			System.out.print("��");
		} // for
		System.out.println();

		for (int i = 0; i < 5; i++) {
			System.out.print("Ŀ��");
		}
		System.out.println();

		for (int i = 0; i < 3; i++) {
			System.out.print("Ŀ�ǿ���");
		}
		System.out.println();
		
		for (int i = 0; i < 3; i++) {
			System.out.println((i + 1) + ": ¯");
		}
	}

}





