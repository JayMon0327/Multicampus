package �ݺ���;

public class For��Ȯ�ι��� {

	public static void main(String[] args) {
		//1. 33~222
		int sum = 0;
		for (int i = 33; i <= 222; i++) {
			sum = sum + i;
		//  33  =  0  + 33
		//  67  =  33 + 34
		//  102 =  67 + 35	
		}
		System.out.println(sum);
		
		//2. 55~4500, 2������
		int sum2 = 0;
		for (int i = 55; i <= 4500; i = i + 2) {
			sum2 = sum2 + i;
		}
		System.out.println(sum2);
		
		//3. 0~6000, 5�� ����
		int sum3 = 0;
		for (int i = 0; i <= 6000; i = i + 5) {
			sum3 = sum3 + i;
		}
		System.out.println(sum3);
		
		
		
		
		
		
		
	}
}







