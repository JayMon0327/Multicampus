package 복습;

public class 기본형데이터 {

	public static void main(String[] args) {
		//정수, 실수, 문자, 논리
		int count = 20;
		double 비율 = 0.25;
		char 층 = '7';
		boolean hot = true;
		System.out.println("총 인원은 " + count + "원");
		System.out.println("총 비율은 " + 비율);
		System.out.println("층수는 " + 층 + "층");
		System.out.println("더운가요 " + hot);
	}

}
