package 반복문;

public class 반복문 {

	public static void main(String[] args) {
		//무한루프
		//게임, 채팅
		while (true) { //조건이 맞을 때, 반복함
			//조건은 무조건 비교연산자=>true/false
			//조건의 결과가 true1
			System.out.println("반갑습니다.");
		}
	}

}
