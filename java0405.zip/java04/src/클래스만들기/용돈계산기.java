package 클래스만들기;

public class 용돈계산기 {
	public void add(int x, int y) {
		System.out.println(x + y + "원");
	}
	public int mul(int x, int y) {
		int result = x * y;
		return result;
	}
}
