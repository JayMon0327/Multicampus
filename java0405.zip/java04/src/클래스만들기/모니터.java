package 클래스만들기;

public class 모니터 {
	//이 부품에서 필요한 기능(function,함수)을 정의
	public void on() {
		System.out.println("콘센트를 이용하다.");
		System.out.println("전원버튼을 눌러 켜다.");
	}
	public void off() {
		System.out.println("전원버튼을 눌러 끄다");
	}
}
