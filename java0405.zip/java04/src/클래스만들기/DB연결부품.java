package 클래스만들기;

public class DB연결부품 {
	
	//기능
	public void create() {
		
	}
	public void read() {
		
	}
	public void update() {
		
	}
	public void delete() {
		
	}
	

}
