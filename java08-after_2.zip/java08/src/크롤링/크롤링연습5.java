package ũ�Ѹ�;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class ũ�Ѹ�����5 {

	public static void main(String[] args) {
		String[] code = {"035720","005930","018260"};
		String[] company = {"īī��","�Ｚ����","�ＺSDS"};
		
		for (int i = 0; i < company.length; i++) {
			try {
				Document doc = Jsoup.connect("https://finance.naver.com/item/main.naver?code=" + code[i]).get();
				System.out.println("-------------------");
				System.out.println("ȸ���: " + company[i]);
				//���ϰ�
				Elements list = doc.select("td.first").select(".blind");
				//<td class="first">
				//System.out.println(list);
				Element tag = list.get(0);
				System.out.println("���ϰ�: " + tag.text());
				String yesterday = tag.text(); //~~~~~~~~~~

				//���簡
				Elements list2 = doc.select("div.today").select(".blind");
				//System.out.println(list2);
				Element tag2 = list2.get(0);
				System.out.println("���簡: " + tag2.text());
				String today = tag2.text(); //~~~~~~~~~~

				//�ð�
				Elements list3 = doc.select("td.first").select(".blind");
				Element tag3 = list.get(1);
				System.out.println("�ð�: " + tag3.text());

			} catch (IOException e) {
				e.printStackTrace();
			} 
		}

	}

}
