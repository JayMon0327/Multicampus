package ����ȯ;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class �ڵ�������3 {
	static JFrame f;

	public static void main(String[] args) {
		f = new JFrame();
		f.setSize(400, 800);
		f.setLayout(new FlowLayout());

		JButton red = new JButton("---��1---");
		JButton yellow = new JButton("---��2---");
		JButton blue = new JButton("---��3---");
		f.add(red);
		f.add(yellow);
		f.add(blue);

		red.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				�ڵ�������3.show("car01.png");
			}
		});
		yellow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				�ڵ�������3.show("car02.png");
			}
		});
		blue.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				�ڵ�������3.show("car03.png");
			}
		});

		f.setVisible(true);
	} // main

	public static void show(String name) {
		ImageIcon icon = new ImageIcon(name);
		JLabel label = new JLabel();
		label.setIcon(icon);
		f.add(label);
		f.setVisible(true);
	}

}
