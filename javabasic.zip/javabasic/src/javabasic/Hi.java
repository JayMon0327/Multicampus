package javabasic;

public class Hi {

	public static void main(String[] args) {
		// syso + 컨트롤 + 스페이스바
		System.out.println("hi");

	}

}
