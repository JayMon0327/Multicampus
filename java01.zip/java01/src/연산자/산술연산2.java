package 연산자;

public class 산술연산2 {

	public static void main(String[] args) {
		
		int n1 = 5;
		int n2 = 4;
		
		int n3 = n1 + n2;
		
		int sum = n1 + n2;
		int n4 = sum / 2;
		System.out.println("평균은 " + n4);
		
		double avg = sum / 2.0;
		System.out.println("제대로 평균은 " + avg);
		
	}

}
