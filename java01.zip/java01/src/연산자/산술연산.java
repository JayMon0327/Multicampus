
package 연산자;

public class 산술연산 {

	public static void main(String[] args) {
		// 산술연산자
		int x = 200;
		int y = 100;
		System.out.println("더한 값은 " + (x + y));
		System.out.println("뺀 값은 " + (x - y));
		System.out.println("곱한 값은 " + (x * y));
		System.out.println("나눈 값은 " + (x / y));
		System.out.println("나머지 값은 " + (x % y));

	}

}
