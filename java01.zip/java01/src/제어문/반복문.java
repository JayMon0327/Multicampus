package 제어문;

public class 반복문 {

	public static void main(String[] args) {
		for (int i = 0; i < 10000; i++) {
			System.out.println("집에 가요.");
		}
	}

}
