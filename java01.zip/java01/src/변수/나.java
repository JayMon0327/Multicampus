package 변수;

public class 나 {

	public static void main(String[] args) {
		// 나에 대한 정보를 간단하게 3개 이상 모니터에 출력해보세요.
		// 출력: 나가는 것.<---> 입력: 들어오는 것.
		//      처리결과가!         처리할 데이터가!
		// 출력은 어디로 할까요?? 모니터, 프린터, 브라우저,
			//              파일, dbms, 네트워크 연결 대상
		// 입력은 어디로부터 할까요?? 키보드, 마우스, 스캐너, 파일,
			//				인터넷, dbms
		
		
		System.out.println("홍길동입니다.");
		System.out.println("100세입니다.");
	}

}
