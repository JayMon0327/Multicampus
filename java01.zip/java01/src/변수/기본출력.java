package 변수;//이 파일이 속해있는 폴더

public class 기본출력 {

	public static void main(String[] args) {
		// 주석, comment, 설명
		// 자동주석, ctrl + /
		System.out.println("오후시간입니다.");
		//sysout, syso ctrl + spacebar
		System.out.println("졸릴 시간이예요.");
		//ctrl + f11: 실행
		//ctrl + s: 저장
		System.out.println("일어날 시간이예요.");
	}
}
