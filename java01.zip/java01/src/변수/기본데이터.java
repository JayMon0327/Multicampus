package 변수;

public class 기본데이터 {

	public static void main(String[] args) {
		//기본 데이터 4가지: 정수, 실수, 문자, 논리
		//기호 => 연산자
		int age = 100;
		double height = 122.2;
		char gender = '남';
		boolean food = true;//false
		System.out.println("오늘은 월요일입니다.");
		System.out.println("내 나이는: " + age); //결합연산자
		//글자들: 문자+문자+문자+...(여러글자, 문자열, String, 실)
	}

}
