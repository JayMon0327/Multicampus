package 연습;

public class 안녕 {

	public static void main(String[] args) {
		System.out.println("반갑습니다.");
	}

}
