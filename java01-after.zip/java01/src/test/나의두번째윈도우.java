package test;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;

public class ���ǵι�°������ {
	private static JTextField textField;
	private static JTextField textField_1;
	private static JTextField textField_2;

	public static void main(String[] args) {
		//jframe, ũ�����ϰ�, ������. ==> windowbuilder��!
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.ORANGE);
		f.setSize(500, 500);
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uC774\uB984");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 20));
		lblNewLabel.setBounds(25, 40, 105, 43);
		f.getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setForeground(Color.BLUE);
		textField.setFont(new Font("����", Font.BOLD, 20));
		textField.setBounds(137, 40, 284, 37);
		f.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\uC804\uD654\uBC88\uD638");
		lblNewLabel_1.setFont(new Font("����", Font.BOLD, 20));
		lblNewLabel_1.setBounds(25, 115, 105, 43);
		f.getContentPane().add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setForeground(Color.BLUE);
		textField_1.setFont(new Font("����", Font.BOLD, 20));
		textField_1.setColumns(10);
		textField_1.setBounds(137, 118, 284, 37);
		f.getContentPane().add(textField_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("\uC8FC\uC18C");
		lblNewLabel_1_1.setFont(new Font("����", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(25, 190, 105, 43);
		f.getContentPane().add(lblNewLabel_1_1);
		
		textField_2 = new JTextField();
		textField_2.setForeground(Color.BLUE);
		textField_2.setFont(new Font("����", Font.BOLD, 20));
		textField_2.setColumns(10);
		textField_2.setBounds(137, 193, 284, 37);
		f.getContentPane().add(textField_2);
		
		JButton btnNewButton = new JButton("\uD655\uC778");
		btnNewButton.setFont(new Font("����", Font.BOLD, 20));
		btnNewButton.setBounds(68, 305, 125, 43);
		f.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton(" \uCDE8\uC18C");
		btnNewButton_1.setFont(new Font("����", Font.BOLD, 20));
		btnNewButton_1.setBounds(237, 305, 125, 43);
		f.getContentPane().add(btnNewButton_1);
		f.setVisible(true);

	}
}
