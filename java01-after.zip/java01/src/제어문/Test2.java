package ���;

public class Test2 {

	public static void main(String[] args) {
		String name = "abc"; //0�� 1��° �ڸ�
		char aChar = name.charAt(0); //"a"
		char bChar = name.charAt(1); //"b"
		System.out.println(aChar + " " + bChar);
		
		float a = 11.1f;
		float b = 22.1f;
		//System.out.println(a^2); //a^����.
		System.out.println(a * a);
	}

}
