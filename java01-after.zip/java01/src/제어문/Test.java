package ���;

import javax.swing.JFrame;

public class Test {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(400, 400);
		f.setVisible(true);
	}

}
