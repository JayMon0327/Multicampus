package Ŭ��������ϱ�;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class �α��� {
	private static JTextField t1;
	private static JTextField t2;
	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.ORANGE);
		f.setBackground(Color.ORANGE);
		f.getContentPane().setForeground(Color.ORANGE);
		f.setSize(500, 500);
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("���̵� :");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel.setBounds(107, 200, 94, 46);
		f.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("��й�ȣ :");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(107, 266, 94, 46);
		f.getContentPane().add(lblNewLabel_1);
		
		t1 = new JTextField();
		t1.setFont(new Font("����", Font.PLAIN, 20));
		t1.setBounds(225, 200, 178, 46);
		f.getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		t2.setFont(new Font("����", Font.PLAIN, 20));
		t2.setColumns(10);
		t2.setBounds(225, 266, 178, 46);
		f.getContentPane().add(t2);
		
		JButton btnNewButton = new JButton("�α���");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String s1 = t1.getText();
				String s2 = t2.getText();
				
				if (s1.equals("root") && s2.equals("1234")) {
					�ϱ��徲�� diary = new �ϱ��徲��();
					diary.open();	
				} else {
					JOptionPane.showMessageDialog(f, "�Է°��� �޶� �α��� ����");
				}
				
			}
		});
		btnNewButton.setBackground(Color.GREEN);
		btnNewButton.setFont(new Font("����", Font.PLAIN, 27));
		btnNewButton.setBounds(83, 349, 129, 63);
		f.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("����");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				t1.setText("");
				t2.setText("");
			}
		});
		btnNewButton_1.setBackground(Color.GREEN);
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 27));
		btnNewButton_1.setBounds(274, 349, 129, 63);
		f.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.setBackground(Color.CYAN);
		btnNewButton_2.setIcon(new ImageIcon("C:\\Users\\user\\Desktop\\javabasic\\java03\\img\\����.jpg"));
		btnNewButton_2.setBounds(107, 27, 296, 147);
		f.getContentPane().add(btnNewButton_2);
		f.setVisible(true);
	}
}