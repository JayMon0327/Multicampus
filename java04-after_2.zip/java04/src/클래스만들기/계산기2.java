package Ŭ���������;

public class ����2 {
	public int add(int x, int y) { //add(100,200)
		return x + y;
	}

	public double add(int x, double y) { //add(100, 22.2)
		return x + y; //100 + 22.2
	}

	public double add(double x, double y) { //add(11.1, 22.2)
		return x + y;
	}

	public String add(String x, int y) { //add("���� ���̴�", 100)
		return x + y;
	}

	public int[] add() {
		int[] num = { 1, 2, 3 };
		return num;
	}
	
	public int multi(int x, int y) {
		return x * y;
	}
	
	public void div(int x, int y) {
		System.out.println("�� ����� " + x / y);
	}
}
