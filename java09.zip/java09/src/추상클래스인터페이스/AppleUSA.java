package 추상클래스인터페이스;

public class AppleUSA extends AppleClass {

	@Override
	public void pay() {
		System.out.println("애플페이를 사용한다.");

	}

}
