package 추상클래스인터페이스;

public class AppleKorea extends AppleClass {

	@Override
	public void pay() {
		System.out.println("다른 카드로 등록하고 써야함.");

	}

}
